# 🚚 Imaklogistic — Plateforme COD

Plateforme SaaS de gestion Cash on Delivery pour l'e-commerce africain.

## 🔐 Connexion démo
- **Email:** admin@imak.ma  
- **Mot de passe:** admin123

## 📦 Modules
- **Dashboard** — KPIs, graphiques, taux de livraison
- **Commandes** — Gestion statuts, import Excel, bulk actions
- **Étiquettes** — Génération & impression bons de livraison
- **Facturation** — Factures hebdomadaires automatiques
- **Accès** — Gestion utilisateurs & permissions

## 🚀 Lancer en local

```bash
npm install
npm run dev
```

## ⚡ Deploy sur Vercel

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/YOUR_USERNAME/imaklogistic)

## 🛠 Stack
- React 18 + Vite
- Recharts
- CSS-in-JS (no Tailwind needed)
